#!/usr/bin/env python3
"""Check all published routes, SEO metadata and local paths."""
import json, sys
from pathlib import Path
from urllib.parse import unquote,urlsplit
from bs4 import BeautifulSoup
root=Path(__file__).resolve().parents[1]
output=root/'dist'
config=json.loads((root/'site-content.json').read_text())
all_pages=list(output.rglob('index.html'))
assert len(all_pages)==len(config['tools'])+len(config['articles'])+2,(len(all_pages),'unexpected page count')
seen_titles=set();problems=[]
for path in all_pages:
 s=BeautifulSoup(path.read_text(encoding='utf-8'),'html.parser')
 title=s.title.text.strip() if s.title else ''
 if not title or title in seen_titles:problems.append((path,'nonunique title'))
 seen_titles.add(title)
 if len(s.select('h1'))!=1:problems.append((path,'expected one H1'))
 if len(s.select('meta[name="description"]'))!=1:problems.append((path,'no meta description'))
 if not s.select('main'):problems.append((path,'no main region'))
 if not s.select('[data-ad-placement]'):problems.append((path,'no ad placement reserved'))
 if path.parent.name!='dist' and path.parent.name not in ('articles',) and path.parent.parent.name=='tools' and not s.select('a[href*="index.html"]'):problems.append((path,'no index links'))
 for tag in s.select('a[href],img[src],link[href],script[src]'):
  value=tag.get('href',tag.get('src',''))
  if not value or value.startswith(('#','https://','http://','mailto:','data:','javascript:')):continue
  local=value.split('?',1)[0].split('#',1)[0]
  if not local:continue
  target=(path.parent/unquote(local)).resolve()
  if target.is_dir():problems.append((path,'directory-link unsupported for file:// preview: '+value));target=target/'index.html'
  if not target.is_file():problems.append((path,'broken local reference: '+value))
if problems:
 for p,m in problems:print('ERROR',p.relative_to(output),m)
 sys.exit(1)
print(f'PASS: {len(all_pages)} standalone indexable pages with unique SEO titles, one H1, descriptions, and working internal asset links.')
print(f'PASS: {len(config["tools"])} tool routes, {len(config["articles"])} article routes plus the homepage and article index.')
print('PASS: every on-site link points to an HTML file, not a bare folder (file:// and GitHub Pages friendly).')
print('PASS: every published page has a labeled ad placement placeholder.')
print('Note: automated SEO file checks do not confirm ranking, hosting, or external CDN functionality.')
