#!/usr/bin/env python3
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
handler=partial(SimpleHTTPRequestHandler,directory=str(root))
server=ThreadingHTTPServer(('127.0.0.1',0),handler)
Thread(target=server.serve_forever,daemon=True).start()
base=f'http://127.0.0.1:{server.server_address[1]}'
site=base+'/dist/index.html'
errors=[]
with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=browser.new_page(viewport={'width':1390,'height':850})
  page.route('https://**',lambda route:route.abort()) # Offline structural test only; CDN processing is outside scope.
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(site,wait_until='domcontentloaded',timeout=15000)
  assert page.locator('h1').count()==1
  assert page.get_by_role('link',name='Full OCR guide').count()==1
  page.get_by_role('link',name='Full OCR guide').click()
  page.wait_for_load_state('domcontentloaded')
  assert page.url.endswith('/tools/image-to-text/index.html'),page.url
  assert page.locator('h1').inner_text()=='Image to Text (OCR)'
  page.get_by_role('link',name='Guides').first.click()
  page.wait_for_load_state('domcontentloaded')
  assert page.url.endswith('/articles/index.html'),page.url
  page.get_by_role('link',name='How to Extract Text from an Image: A Practical Guide').click()
  page.wait_for_load_state('domcontentloaded')
  assert '/articles/how-to-extract-text-from-an-image/index.html' in page.url
  page.get_by_role('link',name='Try Image to Text (OCR)').click()
  page.wait_for_load_state('domcontentloaded')
  assert '/tools/image-to-text/index.html' in page.url
  page.get_by_role('link',name='All tools').first.click()
  page.wait_for_load_state('domcontentloaded')
  assert page.url.split('#')[0].endswith('/dist/index.html'),page.url
  page.get_by_role('link',name='Merge PDFs').click()
  page.wait_for_load_state('domcontentloaded')
  assert '/tools/merge-pdf/index.html' in page.url
  assert page.locator('[data-ad-placement="tool_sidebar"]').count()==1
  page.screenshot(path=str(root/'previews/fixed-merge-pdf-ads.png'),full_page=False)
  print('PASS: Windows file:// offline navigation: homepage -> OCR guide -> articles -> article -> tool -> homepage -> Merge PDFs')
  print('PASS: Ad placeholder found on the tool page')
  # Content Studio: load JSON using file picker, change ads and export a JSON.
  editor=browser.new_page(viewport={'width':1350,'height':850},accept_downloads=True)
  editor.route('https://**',lambda route:route.abort())
  editor.on('pageerror',lambda e:errors.append('EDITOR: '+str(e)))
  editor.goto(base+'/content-editor.html',wait_until='domcontentloaded')
  editor.locator('#importFile').set_input_files(str(root/'site-content.json'))
  editor.get_by_role('button',name='Ad placements').click()
  assert editor.get_by_text('Ad placement settings').count()==1
  editor.locator('#adsEnabled').select_option('true')
  editor.locator('[data-path="ads.client"]').fill('ca-pub-1234567890123456')
  editor.locator('[data-path="ads.slots.home_leaderboard"]').fill('1234567890')
  editor.get_by_role('button',name='Site & SEO settings').click()
  editor.get_by_role('button',name='Ad placements').click()
  assert editor.locator('#adsEnabled').input_value()=='true'
  assert editor.locator('[data-path="ads.slots.home_leaderboard"]').input_value()=='1234567890'
  editor.screenshot(path=str(root/'previews/fixed-content-studio-ads.png'),full_page=False)
  with editor.expect_download() as dinfo:
    editor.locator('#downloadBottom').click()
  download=dinfo.value
  assert download.suggested_filename=='site-content.json'
  print('PASS: Content editor Ads settings persist between tabs and export correctly')
  # mobile page width check for overflow and nav behaviour
  mobile=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
  mobile.route('https://**',lambda route:route.abort())
  mobile.goto(site,wait_until='domcontentloaded')
  assert mobile.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2'),mobile.evaluate('document.documentElement.scrollWidth')
  mobile.screenshot(path=str(root/'previews/fixed-home-mobile.png'),full_page=False)
  print('PASS: Mobile no horizontal overflow at 390px')
  browser.close()
server.shutdown()
print('Page JavaScript errors:',errors)
assert not errors,errors
