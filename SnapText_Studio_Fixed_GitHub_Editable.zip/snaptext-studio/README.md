# SnapText Studio — redesigned, SEO-ready multi-page website

This is a static, editable website based on the supplied 2026 SnapText Studio HTML app. It preserves the existing browser processing libraries and tool handlers, but replaces hash-only tool screens with actual URLs and redesigned workspaces.

## What's included

- **12 dedicated tool URLs:** the original 11 separate tools, plus a standalone Image to Text (OCR) page. The homepage also has the main OCR workspace.
- **3 starter how-to guides**, plus an index of articles.
- **Each tool page contains:** its own unique title, SEO meta description, accessible H1, guide, how-to steps, FAQ section, related tool links, illustration, upload interface, and conversion controls.
- **14 SVG graphics** generated for the website (hero, 12 tool illustrations, favicon).
- **Content Studio:** a visual, local editor for tool descriptions, SEO title/meta, guide sections, FAQs, and newly created standalone articles.
- Clean static HTML for indexability; internal links use regular `<a href>` URLs, not hashes.
- Responsive light/dark theme and local text auto-save.
- `robots.txt`, with `sitemap.xml` and canonical URLs **generated once you set the correct live domain**.

## Files

- `dist/`: **upload the contents of this folder to your website's public root**. `dist/index.html` is the entry point.
- `site-content.json`: all editable pages and guides. Keep it in your project, not necessarily on the public server.
- `content-editor.html`: a local management interface. **Not included in `dist/`**.
- `build.py`: regenerates every HTML page based on `site-content.json` and `source/original.html`.
- `source/original.html`: preserved original code for reference and processing logic.
- `assets/concept-board.png`: AI-generated direction board (reference only, not part of deployed pages).

## Launch locally

From this project folder, install the small build dependency if needed with `python -m pip install -r requirements.txt`. Then:

```bash
python -m http.server 8000
```

Visit `http://localhost:8000/dist/` to preview the deployable site. To open the content editor, visit `http://localhost:8000/content-editor.html`.

If using Windows, the command can also be `py -m http.server 8000`.

## Update SEO text, descriptions, FAQs or articles

1. Open `content-editor.html` via your local server, or open it directly in a browser and **Import content JSON** from `site-content.json`.
2. Select the tool page you want to edit, or choose **New article**. Adjust titles, summaries, introductions, article sections and FAQs.
3. Click **Export site-content.json** and replace the existing project JSON file with the downloaded one.
4. Run:

```bash
python build.py
```

5. Upload the refreshed `dist/` contents to your hosting provider. A new article produces a brand-new crawlable URL such as `/articles/my-new-guide/`.

This is a **build-time content editor**, not a hosted authenticated CMS; browser-side changes aren't published until you regenerate and deploy. To publish instantly from a remote dashboard, you would need to add a CMS/backend such as a Git-based CMS or hosted headless CMS.

## SEO setup — IMPORTANT

The `site.base_url` entry in `site-content.json` intentionally starts empty. You must enter **your actual public HTTPS domain** in Content Studio's *Site & SEO settings*, for example `https://your-real-domain.com`, then export the JSON and rebuild.

After setting a real domain, the build adds:

- Absolute page-specific `<link rel="canonical">` tags
- A valid `dist/sitemap.xml` listing all generated pages
- The `Sitemap` directive in `dist/robots.txt`
- Absolute Open Graph URLs and preview images

Until you set the domain, canonical tags and `sitemap.xml` are omitted instead of publishing incorrect URLs.

Deploy to a static host that supports `/tools/<slug>/` URLs resolving to `index.html` (most static hosts do). Do not deploy solely with a JavaScript hash router. After publication, verify HTTP 200 for individual URLs, submit the sitemap to Google Search Console, and use URL Inspection for important pages. Indexing and ranking are **not guaranteed** by the code itself: site authority, competition, topical usefulness and other signals matter.

## Current tool limitations carried over from the original

- PDF to Word extracts text with OCR fallback; does not guarantee reproduction of complex layouts.
- PDF compression rasterizes each page. It may result in a larger PDF, and selectable text/forms/links may be lost.
- Background removal is simple sampled-color removal, not AI subject separation.
- Images to PDF fits each input image into an A4 portrait page.
- OCR PDF export opens the browser print flow; choose **Save as PDF**.
- External libraries, OCR language data and web fonts load from third-party CDNs. Processing happens locally in-browser, but the app is not truly offline. Check network access and CDN policies for your deployment.
- Cropped scans are passed to the OCR page using local IndexedDB rather than the original same-page-only transfer.

## Development validation

Generated HTML contains semantic H1, visible guide content, metadata and normal internal links without client-side rendering. The original tool engine logic has been retained as a shared `assets/app.js`, with guards for independent pages; file-picker UX adds drag/drop and ordering for multiple files. Build and JS syntax checked. A browser runtime smoke test should be performed on your actual hosting environment, especially PDF- and OCR-processing libraries provided by CDNs.


## Fixed local links (November 2026 update)

All links now target actual `index.html` files (for example `tools/image-to-text/index.html` and `articles/index.html`) so clicking them in an extracted Windows folder will not open an "Index of directory" page. Do not run the pages inside ZIP previews; extract the archive first. Individual pages are also directly linked in their headers, breadcrumbs, related-tools sections and article references.

## Ads: reserved placements and configuration

Every page includes clearly labeled **Advertisement** placeholder regions, which intentionally display no real ad until configured. Placements:

| Setting | Location |
| --- | --- |
| `home_leaderboard` | Homepage below the hero |
| `home_middle` | Homepage between OCR and tools |
| `tool_inline` | Each tool page above its guide |
| `tool_sidebar` | Tool page beside its written guide |
| `article_index` | Guides landing page |
| `article_inline` | Individual article above its body |
| `article_sidebar` | Beside an individual article |

To enable AdSense, first get an approved site and your own Publisher ID and ad unit IDs from AdSense. Open local `content-editor.html` and import `site-content.json` if prompted. Choose **Ad placements** in the left navigation, switch Activate ads to Yes, enter the real `ca-pub-...` publisher ID and numeric ad-unit IDs for each desired placement, and export. Replace the JSON and run `python build.py`. Ads are never fabricated or enabled by default. Avoid placing ads to imitate tool buttons, and follow Google AdSense policies. With ads left disabled, the ad slots remain visible as reserved placeholders for design planning.

## Publish the website to GitHub Pages — straightforward route

1. Download the **Ready-to-Upload** ZIP and extract it. (If using the complete editable source, the already-built `docs/` folder contains the same website files.)
2. Sign in to [GitHub](https://github.com), create a repository such as `snaptext-studio` and choose **Public** if using free GitHub Pages.
3. In the repository, click **Add file → Upload files** and upload **the contents of the extracted ZIP**, so `index.html`, `articles/`, `tools/`, `assets/`, `.nojekyll` and `robots.txt` are at the repository root. For many folders, use GitHub Desktop or Git on your machine rather than the web file upload interface.
4. Commit changes, then go to **Settings → Pages → Build and deployment → Deploy from a branch → main → /(root) → Save**.
5. Your default project-site URL should be `https://YOUR_GITHUB_USERNAME.github.io/snaptext-studio/` (if you used that repository name). This is not automatically a custom domain.
6. In the **editable project**, enter this exact published HTTPS URL into **Content Studio → Site & SEO settings → Live HTTPS domain**. Export `site-content.json`, replace the project copy, run `python build.py`, and re-upload refreshed website files. That generates the correct sitemap and canonical tags, including the repository path.
7. In **Google Search Console**, verify your site and submit `sitemap.xml` only after it exists on the published URL.

### Alternative for the complete source code repository

The complete editable ZIP includes `build.py`, `site-content.json`, `content-editor.html`, and a fully generated `docs/` folder. Upload the source files to GitHub and use **Settings → Pages → Deploy from a branch → main → /docs**. When you rebuild locally, also run `python build.py --output docs` and push the updated `docs/` files, because GitHub Pages will serve the `docs/` files, not the `dist/` files. Do not include your personal accounts, API keys or unapproved advertisement IDs in a public repository.

### Quick terminal commands (optional)

After extracting the **complete editable project**, inside the folder:

```bash
git init
git add .
git commit -m "Fix routes, internal links and add ad placements"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/snaptext-studio.git
git push -u origin main
```

Create the empty repository on GitHub first. Follow the branch and `/docs` setup above. Replace the placeholder username with your actual account; don't use that example as a real destination.

### Validation and remaining checks

`python tests/check_build.py` checks all 17 HTML pages, file references, SEO titles, internal links, and ad placeholders. `node --check dist/assets/app.js` verifies JavaScript syntax. Browser-based end-to-end and CDN processing tests could not be run in this environment because Chromium navigation is blocked by administrator policy; verify an actual PDF merge, OCR extraction, QR generation, file drag/drop and local navigation on your deployed GitHub Pages URL before launch. AdSense will not necessarily approve a `github.io` project URL, and Google search rankings are not automatic.
