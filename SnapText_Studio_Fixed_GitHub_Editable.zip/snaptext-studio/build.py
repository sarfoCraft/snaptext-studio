#!/usr/bin/env python3
"""SnapText Studio static site builder. Python stdlib + BeautifulSoup 4.
Run: python build.py --output dist
"""
import argparse, json, html, re, shutil, textwrap
from pathlib import Path
from datetime import date
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parent
DATA = json.loads((ROOT/'site-content.json').read_text(encoding='utf-8'))
SITE = DATA['site']
ALL_TOOLS = DATA['tools']
CORE = BeautifulSoup((ROOT/'source/original.html').read_text(encoding='utf-8'), 'html.parser')
TOOLS = {t['id']:t for t in ALL_TOOLS}
GROUPS = ['PDF tools','Image tools','OCR & scanning']
LEGACY_CSS = CORE.style.get_text()
LEGACY_JS = CORE.find_all('script')[-1].get_text()
ESC = lambda s: html.escape(str(s),quote=True)

THEME = r'''
/* ===== SNAPTEXT STUDIO DESIGN SYSTEM / 2026 ===== */
:root{--bg:#f8f9fe;--bg-alt:#eff2fc;--surface:#fff;--surface-2:#fafbff;--ink:#151438;--ink-2:#4a4b68;--muted:#6f7390;--muted-2:#9298af;--line:#e8eaf4;--line-2:#dcdff0;--purple:#6443e8;--purple-2:#8c69ff;--purple-soft:#f1edff;--navy:#191641;--radius:18px;--radius-lg:26px;--shadow:0 14px 50px rgba(28,26,75,.055);--shadow-lg:0 30px 75px rgba(55,37,134,.12)}
[data-theme="dark"]{--bg:#0c1020;--bg-alt:#11182b;--surface:#161e33;--surface-2:#192139;--ink:#f8f8ff;--ink-2:#d3d8ea;--muted:#a5afca;--muted-2:#8995b1;--line:#2a3550;--line-2:#3a4562;--purple:#a38bff;--purple-2:#8767f9;--purple-soft:#252242;--navy:#5641bd;--shadow:0 14px 40px #0005;--shadow-lg:0 25px 60px #0007}
*,*::before,*::after{box-sizing:border-box}
body{font-family:'DM Sans',sans-serif;font-size:15px;background:var(--bg);color:var(--ink)}
a{color:inherit}a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible,[tabindex]:focus-visible{outline:3px solid #b3a2ff;outline-offset:3px}
.app-shell{max-width:1500px;padding:0 5%;margin:auto}
.topbar{height:82px;gap:22px;z-index:90}
.topbar .brand{flex:none}.brand-mark{width:42px;height:42px;border-radius:13px}.brand-name{letter-spacing:-1px}
.topbar-right{gap:18px}.top-link{font-size:13px}.nav-desktop{display:flex;align-items:center;gap:4px;margin-left:auto}.nav-desktop a{font-size:13px;font-weight:700;padding:10px 15px;text-decoration:none;border-radius:10px;color:var(--ink-2)}.nav-desktop a:hover,.nav-desktop a[aria-current="page"]{background:var(--purple-soft);color:var(--purple)}
.nav-cta{background:linear-gradient(125deg,#845af8,#573ce5);color:#fff!important;border-radius:11px;box-shadow:0 7px 20px #623ee340}.nav-cta:hover{background:#6348e9!important;color:#fff!important}.topbar-right .top-link{display:none}.theme-toggle{width:42px;height:42px}
.page-body{min-height:60vh}.page-lead{color:var(--muted);line-height:1.8;max-width:700px}
.eyebrow-new,.kicker{display:inline-flex;align-items:center;gap:8px;color:var(--purple);font-weight:800;letter-spacing:1.3px;text-transform:uppercase;font-size:11px}
.kicker::before,.eyebrow-new::before{content:'';height:7px;width:7px;border-radius:50%;background:#8870ff;box-shadow:0 0 0 5px #8c69ff21}
.hero-new{padding:76px 0 52px;display:grid;grid-template-columns:minmax(0,1fr) minmax(360px,.97fr);align-items:center;gap:25px;position:relative}
.hero-new::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 70% 35%,#887aff1a,transparent 63%);pointer-events:none;z-index:-1}
.hero-new h1{font:800 clamp(41px,4.8vw,71px)/1.075 'Manrope',sans-serif;letter-spacing:-3.6px;margin:20px 0 20px;max-width:690px}
.hero-new h1 em{font-style:normal;background:linear-gradient(120deg,#6351ff,#9566e7);background-clip:text;-webkit-background-clip:text;color:transparent}
.hero-new p{font-size:15px;line-height:1.85;color:var(--muted);max-width:540px;margin-bottom:24px}
.hero-art{width:100%;height:auto;filter:drop-shadow(0 20px 40px #704be519)}.hero-actions{display:flex;gap:12px;flex-wrap:wrap}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:10px;text-decoration:none;font-weight:800;font-size:13px;border-radius:12px;padding:15px 22px;transition:.2s}
.btn-main{color:#fff;background:linear-gradient(110deg,#7755f4,#5638dd);box-shadow:0 9px 23px #7550f33d}.btn-main:hover{transform:translateY(-2px);box-shadow:0 11px 26px #7550f35c}.btn-outline{background:var(--surface);border:1px solid var(--line-2)}.btn-outline:hover{border-color:#947bfa;color:var(--purple)}
.trust-row{display:flex;gap:20px;flex-wrap:wrap;margin-top:30px}.trust-row span{font-weight:700;color:var(--ink-2);font-size:12px;display:flex;align-items:center;gap:6px}.trust-row i{display:grid;place-items:center;color:var(--purple);font-style:normal}
.section-heading{display:flex;justify-content:space-between;align-items:end;gap:20px;margin-bottom:24px}.section-heading h2{font:800 clamp(28px,3vw,38px)/1.2 'Manrope',sans-serif;letter-spacing:-1.8px;margin:9px 0}.section-heading p{color:var(--muted);line-height:1.7;margin:0;max-width:580px;font-size:14px}
.section-link{font-size:13px;font-weight:800;text-decoration:none;color:var(--purple);white-space:nowrap;padding-bottom:7px}
.home-workspace{padding:30px 0 75px}.home-workspace .workspace{padding:28px;border-radius:26px}.workspace-heading h2{font-size:25px}.workspace-grid{gap:22px}.panel{background:var(--surface-2);padding:24px}.dropzone{height:185px;border-width:2px;background:var(--surface);border-color:#c9bcff}.dropzone:hover,.dropzone.dragover{background:var(--purple-soft)}.editor-wrap textarea{min-height:290px;font-size:13px}.ocr-button{min-height:50px;font-size:13px}.privacy-note{font-size:11px;line-height:1.5}.workspace .panel-heading h3{font-size:17px}
.tools-gallery{padding:30px 0 72px}.filter-bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:20px 0 27px}.filter-bar button{cursor:pointer;border:1px solid var(--line);border-radius:100px;background:var(--surface);color:var(--ink-2);font-size:12px;font-weight:800;padding:11px 18px}.filter-bar button[aria-pressed="true"]{background:var(--navy);border-color:var(--navy);color:#fff}
.tools-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}
.tool-tile{border:1px solid var(--line);background:var(--surface);border-radius:20px;display:flex;flex-direction:column;overflow:hidden;text-decoration:none;transition:.25s;min-width:0;box-shadow:0 5px 20px #27245105}
.tool-tile:hover{transform:translateY(-4px);box-shadow:0 19px 47px #29214d14;border-color:#aa99ff}
.tile-visual{background:color-mix(in srgb,var(--tile-color) 7%,var(--surface));padding:14px 22px 0;position:relative;height:170px;display:flex;align-items:center;justify-content:center}.tile-visual img{height:100%;width:100%;object-fit:contain}.tile-body{padding:18px 21px 21px;flex:1}.tile-meta{font-size:10px;letter-spacing:1px;font-weight:800;text-transform:uppercase;color:var(--tile-color)}.tile-body h3{margin:8px 0;font:800 17px 'Manrope',sans-serif;letter-spacing:-.6px}.tile-body p{font-size:12px;line-height:1.65;color:var(--muted);min-height:40px;margin-bottom:12px}.tile-bottom{display:flex;align-items:center;justify-content:space-between;font-size:12px;font-weight:800;color:var(--purple)}.tile-bottom span:last-child{width:28px;height:28px;border-radius:50%;background:var(--purple-soft);display:grid;place-items:center}
.benefits{padding:35px 0 85px;display:grid;grid-template-columns:repeat(4,1fr);gap:16px}.benefit{background:var(--surface);border:1px solid var(--line);padding:25px;border-radius:17px}.benefit .emoji{font-size:25px;display:block;margin-bottom:14px}.benefit h3{font:800 14px 'Manrope',sans-serif;margin-bottom:7px}.benefit p{font-size:12px;line-height:1.7;color:var(--muted);margin:0}
.article-preview{padding-bottom:80px}.blog-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}.blog-card{text-decoration:none;display:block;background:var(--surface);border:1px solid var(--line);border-radius:18px;padding:23px;min-height:180px;transition:.2s}.blog-card:hover{transform:translateY(-2px);box-shadow:var(--shadow)}.blog-card span{font-size:11px;color:var(--purple);font-weight:800}.blog-card h3{font:800 17px/1.4 'Manrope',sans-serif;margin:12px 0}.blog-card p{font-size:12px;line-height:1.7;color:var(--muted)}
.breadcrumbs{display:flex;gap:9px;flex-wrap:wrap;color:var(--muted);font-size:12px;margin:25px 0}.breadcrumbs a{text-decoration:none;color:var(--muted)}.breadcrumbs a:hover{color:var(--purple)}
.tool-page{padding:0 0 88px;animation:none;min-height:50vh}
.tool-hero{display:grid;grid-template-columns:minmax(0,1fr) minmax(250px,.45fr);gap:20px;align-items:center;padding:16px 0 26px}
.tool-hero h1{font:800 clamp(32px,3.2vw,48px)/1.15 'Manrope',sans-serif;letter-spacing:-2px;margin:12px 0}.tool-hero p{font-size:15px;line-height:1.8;color:var(--muted);max-width:670px;margin:0 0 13px}.tool-hero img{display:block;max-height:240px;width:100%;object-fit:contain}
.tagline-row{display:flex;gap:9px;flex-wrap:wrap}.small-tag{background:var(--surface);border:1px solid var(--line);border-radius:100px;padding:7px 11px;color:var(--ink-2);font-size:11px;font-weight:800}.small-tag b{color:#17a878}
.tool-workbench{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(245px,.7fr);gap:22px;align-items:start;margin:12px 0 64px}.tool-page-card{max-width:none;padding:29px;background:var(--surface);border-radius:22px;box-shadow:var(--shadow);min-height:300px}.tool-page-card .tool-field-label{font-size:12px;font-weight:800;margin:18px 0 9px}.tool-page-card .tool-action{height:50px;border-radius:12px;font-size:13px;margin-top:22px;background:linear-gradient(110deg,#7653f0,#5b3be4)}.tool-page-card .tool-action:hover:not(:disabled){background:#6040eb}.tool-page-card .tool-select,.tool-page-card .tool-text-input{height:48px;font-size:13px}.tool-page-card .tool-result{font-size:13px}.tool-page-card .tool-status{font-size:12px;line-height:1.7;margin-top:14px}.tool-page-card .tool-range{height:28px}.enhanced-drop{border:2px dashed #c9bdf4;background:var(--surface-2);border-radius:17px;padding:34px 18px;min-height:184px;display:grid;place-content:center;text-align:center;cursor:pointer;transition:.2s}.enhanced-drop::before{content:'⇧';margin:0 auto 9px;background:var(--purple-soft);color:var(--purple);font-size:23px;font-weight:800;width:48px;height:48px;border-radius:14px;display:grid;place-items:center}.enhanced-drop:hover,.enhanced-drop.dragover{background:var(--purple-soft);border-color:var(--purple)}.enhanced-drop .file-trigger{height:42px;border:0;background:var(--purple);color:white;border-radius:10px;font-size:12px;max-width:230px;margin:auto;padding:0 18px;cursor:pointer}.enhanced-drop small{font-size:11px;color:var(--muted);margin-top:12px}.enhanced-drop .file-trigger:hover{background:#563add;color:#fff}.file-list{display:flex;flex-direction:column;gap:9px;margin:15px 0 0;padding:0;list-style:none}.file-row{background:var(--surface-2);border:1px solid var(--line);border-radius:10px;padding:10px 12px;display:flex;gap:10px;align-items:center}.file-chip{display:grid;place-items:center;width:32px;height:35px;flex:none;background:#ebebff;color:var(--purple);border-radius:8px;font-size:9px;font-weight:900}.file-name{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;font-weight:700}.file-size{font-size:11px;color:var(--muted)}.file-row button{width:29px;height:29px;border-radius:7px;border:1px solid var(--line-2);background:var(--surface);color:var(--ink);cursor:pointer}.file-row button:disabled{opacity:.3;cursor:default}
.workbench-side{background:var(--surface);border:1px solid var(--line);border-radius:22px;padding:19px 22px 22px;box-shadow:var(--shadow-sm)}.workbench-side img{display:block;width:100%;max-height:220px;object-fit:contain;background:var(--bg-alt);border-radius:14px;margin-bottom:20px}.workbench-side h3{font:800 16px 'Manrope',sans-serif;margin:0 0 9px}.workbench-side p{color:var(--muted);font-size:12px;line-height:1.7}.workbench-side ul{list-style:none;margin:14px 0 0;padding:0}.workbench-side li{font-size:12px;color:var(--ink-2);line-height:1.65;padding:8px 0;border-top:1px solid var(--line);display:flex;gap:9px}.workbench-side li::before{content:'✓';color:#13a780;font-weight:900}
.editorial-grid{display:grid;grid-template-columns:minmax(0,1fr) 250px;gap:55px}.editorial h2{font:800 25px/1.3 'Manrope',sans-serif;letter-spacing:-.8px;margin:32px 0 12px}.editorial h3{font:800 18px/1.3 'Manrope',sans-serif;margin:27px 0 11px}.editorial p,.editorial li{color:var(--ink-2);font-size:14px;line-height:1.92}.editorial .intro-text{font-size:15px;color:var(--ink-2)}.steps-list{padding:0;list-style:none;counter-reset:steps}.steps-list li{display:flex;gap:14px;align-items:start;padding:11px 0}.steps-list li::before{counter-increment:steps;content:counter(steps);display:grid;place-items:center;flex:none;width:28px;height:28px;border-radius:9px;background:var(--purple-soft);color:var(--purple);font-size:12px;font-weight:800}.faq-list details{border-bottom:1px solid var(--line);padding:15px 0}.faq-list summary{cursor:pointer;font-weight:800;font-size:14px}.faq-list p{margin-bottom:3px}.article-toc{position:sticky;top:104px;padding:22px;border-radius:16px;background:var(--surface);border:1px solid var(--line);height:fit-content}.article-toc h3{font:800 14px 'Manrope',sans-serif;margin:0 0 14px}.article-toc a{display:block;padding:8px 0;font-size:12px;color:var(--muted);text-decoration:none}.article-toc a:hover{color:var(--purple)}.related-tools{margin-top:55px;border-top:1px solid var(--line);padding-top:32px}.related-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.related-grid a{background:var(--surface);border:1px solid var(--line);padding:15px 17px;text-decoration:none;border-radius:13px;font-size:13px;font-weight:800}.related-grid a:hover{border-color:#9e83fa;color:var(--purple)}
.article-page{max-width:1050px;margin:auto;padding-bottom:90px}.article-page .blog-hero{max-width:860px;padding:20px 0 24px}.article-page h1{font:800 clamp(32px,4vw,53px)/1.12 'Manrope',sans-serif;letter-spacing:-2px;margin:14px 0}.article-page .blog-hero p{color:var(--muted);font-size:16px;line-height:1.75}.article-page .editorial-grid{grid-template-columns:minmax(0,1fr) 240px}.article-page .editorial{max-width:720px}
.blog-index{padding:65px 0 100px}.blog-index h1{font:800 48px 'Manrope',sans-serif;letter-spacing:-2px;margin:12px 0}.blog-index .blog-grid{margin-top:40px}
.footer-wrap{margin:40px 0 0;border-top:1px solid var(--line)}.footer{min-height:135px;gap:18px}.footer-links{display:flex;flex-wrap:wrap;gap:18px;margin-left:auto}.footer-links a{text-decoration:none;font-size:12px;font-weight:700;color:var(--muted)}.footer-links a:hover{color:var(--purple)}.footer-right{margin-left:0}.toast{z-index:300}
.u-hide{display:none!important}
@media(max-width:1050px){.app-shell{padding:0 3.5%}.nav-desktop{gap:1px}.nav-desktop a{padding:9px}.hero-new{grid-template-columns:1fr 1fr}.hero-new h1{font-size:50px}.tools-cards{grid-template-columns:repeat(2,1fr)}.tool-workbench{grid-template-columns:1.2fr .8fr}.editorial-grid{grid-template-columns:1fr 210px;gap:28px}}
@media(max-width:760px){.app-shell{padding:0 18px}.topbar{height:70px}.brand-mark{width:37px;height:37px}.brand-name{font-size:17px}.nav-desktop{display:none}.nav-cta{padding:9px 11px;font-size:11px}.privacy-pill{display:none}.hero-new{padding:48px 0 40px;display:flex;flex-direction:column;align-items:stretch;gap:8px}.hero-new h1{font-size:clamp(39px,9vw,54px);letter-spacing:-2.6px}.hero-new p{font-size:14px}.hero-new .hero-art{width:min(100%,520px);margin:12px auto}.trust-row{margin-top:22px}.home-workspace{padding:0 0 60px}.home-workspace .workspace{padding:15px}.workspace-heading{gap:12px}.section-heading{align-items:start;flex-direction:column}.tools-cards,.blog-grid{grid-template-columns:1fr}.tile-visual{height:200px}.benefits{grid-template-columns:repeat(2,1fr);padding-bottom:60px}.tool-hero{grid-template-columns:1fr;padding:5px 0 16px}.tool-hero h1{font-size:34px;letter-spacing:-1.5px}.tool-hero img{max-height:190px;max-width:340px;margin:auto}.tool-workbench,.editorial-grid,.article-page .editorial-grid{grid-template-columns:1fr;gap:26px}.tool-page-card{padding:20px}.workbench-side{display:none}.article-toc{position:static;order:-1}.article-page h1{font-size:36px}.footer{padding:22px 0;flex-wrap:wrap;min-height:0}.footer-links{order:2;margin-left:0;width:100%}.footer-right{order:3;width:100%}.panel{padding:15px}.workspace-grid{grid-template-columns:1fr}}
@media(max-width:440px){.benefits{grid-template-columns:1fr}.brand-name{font-size:15px}.nav-cta{font-size:10px}.tool-hero img{max-height:145px}.tile-visual{height:170px}.editorial p,.editorial li{font-size:13px}.topbar-right{gap:5px}.theme-toggle{width:36px;height:36px}.footer .brand{max-width:160px}.tool-page-card{padding:16px}.file-row{flex-wrap:wrap}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{scroll-behavior:auto!important;transition-duration:.01ms!important;animation-duration:.01ms!important}}

/* Advertising spaces: visually separated from primary tool actions. */
.ad-placement{margin:28px 0 36px;min-width:0;overflow:hidden}
.ad-placement .ad-label{display:block;text-transform:uppercase;letter-spacing:1.3px;font-size:10px;color:var(--muted-2);font-weight:700;text-align:center;margin:0 0 8px}
.ad-reserved{display:flex;justify-content:center;align-items:center;flex-direction:column;gap:7px;border:1px dashed var(--line-2);background:var(--surface-2);border-radius:14px;min-height:130px;color:var(--muted);text-align:center;padding:16px}
.ad-reserved strong{font:700 13px 'Manrope',sans-serif;color:var(--muted)}.ad-reserved span{font-size:11px;line-height:1.4}
.ad-placement--sidebar{margin:24px 0 0}.ad-placement--sidebar .ad-reserved{min-height:240px}
.ad-placement--inline .ad-reserved{min-height:115px}
.ad-placement ins.adsbygoogle{min-height:100px}
.editorial-aside{min-width:0}.editorial-aside .article-toc{position:sticky;top:104px}
.related-reading{border-top:1px solid var(--line);margin-top:35px;padding-top:26px}.related-reading h2{font:800 22px Manrope,sans-serif}.related-reading a{text-decoration:none;color:var(--purple);font-weight:700}
@media(max-width:760px){.ad-placement{margin:22px 0 28px}.ad-placement--sidebar .ad-reserved{min-height:120px}.editorial-aside{order:-1}.editorial-aside .article-toc{position:static}}

'''

# Make the same original processing engines work on independently loaded HTML pages.
NAV = r'''
/* Static HTML navigation: unique crawlable routes, no hash-only screens. */
function navigateTo(route) {
  const href = (window.SNAPTEXT_ROUTES || {})[route] || window.SNAPTEXT_HOME || '/';
  window.location.assign(href);
}
'''
start = LEGACY_JS.index('/* ============ CLIENT-SIDE ROUTING (SPA) ============ */')
end = LEGACY_JS.index('/* ============ CATEGORY NAV (HOME) ============ */')
SCRIPT = LEGACY_JS[:start] + NAV + LEGACY_JS[end:]
SCRIPT = SCRIPT.replace("      const $ = (id) => document.getElementById(id);\n      const els = {", "      const $ = (id) => document.getElementById(id);\n      if (!$('imageInput')) return; // OCR only on homepage and its dedicated page.\n      const els = {",1)
# Original crop code assumes the home OCR input shares the same DOM; use an IndexedDB hand-off instead.
crop_a = "          const file = new File([blob], 'cropped-document.png', { type: 'image/png' });"
crop_b = "          setStatus('cropStatus', 'Cropped image sent to the main OCR workspace.', 'success');"
assert crop_a in SCRIPT and crop_b in SCRIPT
idx_a=SCRIPT.index(crop_a); idx_b=SCRIPT.index(crop_b)+len(crop_b)
SCRIPT=SCRIPT[:idx_a]+"          await window.SnapTextTransfer.save(blob);\n          navigateTo('home');"+SCRIPT[idx_b:]
# Restore autosaved editor text and accept cropped image on dedicated OCR page.
restore='''
      try { const draft = localStorage.getItem('snaptext-editor-draft'); if (draft) els.textOutput.value = draft; } catch (_) {}
      window.SnapTextTransfer.take().then(blob => { if (blob) setImage(new File([blob], 'cropped-document.png', { type:'image/png' })); }).catch(console.warn);
'''
SCRIPT=SCRIPT.replace("      updateCounts();\n    })();",restore+"      updateCounts();\n    })();",1)
SCRIPT=SCRIPT.replace("      els.textOutput.addEventListener('input', updateCounts);", "      els.textOutput.addEventListener('input', () => { updateCounts(); try { localStorage.setItem('snaptext-editor-draft', els.textOutput.value); setEditorStatus('Saved locally',true); } catch (_) { setEditorStatus('Local save unavailable'); }});",1)
SCRIPT=SCRIPT.replace("      function resetAll() {\n        if (busy) return;", "      function resetAll() {\n        if (busy) return;\n        try { localStorage.removeItem('snaptext-editor-draft'); } catch (_) {}",1)
SCRIPT=SCRIPT.replace("els.textOutput.value = ''; updateCounts(); els.confidenceLabel.textContent = 'Text cleared'", "els.textOutput.value = ''; try { localStorage.removeItem('snaptext-editor-draft'); } catch (_) {} updateCounts(); els.confidenceLabel.textContent = 'Text cleared'",1)
# On OCR-only pages use site URL fallback for back to all tools.
TRANSFER = r'''
window.SnapTextTransfer = (() => {
 const NAME='snaptext-studio-transfer';
 const open=()=>new Promise((resolve,reject)=>{
   const request=indexedDB.open(NAME,1);
   request.onupgradeneeded=()=>{ if(!request.result.objectStoreNames.contains('files')) request.result.createObjectStore('files'); };
   request.onsuccess=()=>resolve(request.result); request.onerror=()=>reject(request.error);
 });
 async function run(mode, operation){ const db=await open(); return new Promise((resolve,reject)=>{
   const tx=db.transaction('files',mode), store=tx.objectStore('files');
   const req=operation(store); req.onsuccess=()=>resolve(req.result); req.onerror=()=>reject(req.error);
   tx.oncomplete=()=>db.close(); tx.onerror=()=>reject(tx.error);
 }); }
 return {save: async blob=>run('readwrite', s=>s.put(blob,'crop')),
         take: async ()=>{const blob=await run('readonly',s=>s.get('crop'));if(blob)await run('readwrite',s=>s.delete('crop'));return blob;}};
})();
'''
# Extra upload and gallery helpers (UI only), respect existing processing functions.
ENHANCEMENTS=r'''
document.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('[data-drop-input]').forEach(zone=>{
   const input=document.getElementById(zone.dataset.dropInput), list=document.querySelector(`[data-file-list="${zone.dataset.dropInput}"]`);
   if(!input)return;
   const redraw=()=>{
     if(!list)return;
     const files=Array.from(input.files||[]); list.innerHTML='';
     files.forEach((file,i)=>{
       const row=document.createElement('li');row.className='file-row';
       const type=document.createElement('span');type.className='file-chip';type.textContent=file.type.includes('pdf')?'PDF':'IMG';
       const name=document.createElement('span');name.className='file-name';name.textContent=file.name;name.title=file.name;
       const size=document.createElement('span');size.className='file-size';size.textContent=(file.size/1024/1024).toFixed(2)+' MB';
       row.append(type,name,size);
       if(input.multiple&&files.length>1){
         for(const [direction,symbol] of [[-1,'↑'],[1,'↓']]){
           const btn=document.createElement('button');btn.type='button';btn.textContent=symbol;btn.title=direction===-1?'Move earlier':'Move later';
           btn.setAttribute('aria-label',`${direction===-1?'Move earlier':'Move later'}: ${file.name}`);
           btn.disabled=(i===0&&direction===-1)||(i===files.length-1&&direction===1);
           btn.addEventListener('click',()=>{
             const newFiles=Array.from(input.files);[newFiles[i],newFiles[i+direction]]=[newFiles[i+direction],newFiles[i]];
             const dt=new DataTransfer();newFiles.forEach(f=>dt.items.add(f));input.files=dt.files;
             input.dispatchEvent(new Event('change',{bubbles:true}));
           });row.appendChild(btn);
         }
       }
       list.append(row);
     });
   };
   input.addEventListener('change',redraw);
   zone.addEventListener('dragover',e=>{e.preventDefault();zone.classList.add('dragover')});
   zone.addEventListener('dragleave',()=>zone.classList.remove('dragover'));
   zone.addEventListener('drop',e=>{
     e.preventDefault();zone.classList.remove('dragover');const dt=new DataTransfer();
     Array.from(e.dataTransfer.files||[]).filter(f=>{
       if(input.accept.includes('pdf'))return f.type==='application/pdf'||f.name.toLowerCase().endsWith('.pdf');
       return f.type.startsWith('image/');
     }).slice(0,input.multiple?100:1).forEach(f=>dt.items.add(f));
     if(dt.files.length){input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));}
   });
   zone.addEventListener('click',e=>{if(e.target.closest('label'))return;input.click()});
   zone.setAttribute('role','button');zone.setAttribute('tabindex','0');
   zone.setAttribute('aria-label','Drop files here or choose files');
   zone.addEventListener('keydown',e=>{if(e.target===zone&&(e.key==='Enter'||e.key===' ')){e.preventDefault();input.click()}});
 });
 document.querySelectorAll('.filter-bar button').forEach(button=>{
   button.addEventListener('click',()=>{
     document.querySelectorAll('.filter-bar button').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
     document.querySelectorAll('.tool-tile').forEach(card=>{
       card.classList.toggle('u-hide',button.dataset.filter!=='All'&&card.dataset.group!==button.dataset.filter);
     });
   });
 });
});
'''

# SVG illustrations. Each tool has its own actual image file (not emoji icons).
def create_illustration(tool):
    c=tool['color']; symbol=ESC(tool['symbol']); slug=tool['slug']
    icons={
      'pdf-word':('PDF','W','↗'), 'pdf-images':('PDF','PNG','⇢'),'images-pdf':('JPG','PDF','⇢'),
      'merge-pdf':('PDF','PDF','+'),'split-pdf':('PDF','1–3','↗'),'compress-pdf':('PDF','SMALL','↓'),
      'image-convert':('JPG','PNG','⇄'),'bg-remover':('IMG','PNG','✧'),'batch-ocr':('IMG','TXT','⇢'),
      'crop-tool':('SCAN','CROP','⌗'),'qr-gen':('LINK','QR','⇢'),'image-to-text':('IMG','TXT','⇢')}
    left,right,arrow=icons[tool['id']]
    dotgrid=''.join(f'<rect x="{x}" y="{y}" width="10" height="10" rx="2" fill="#1b1845"/>' for x,y in [(348+xx*13,107+yy*13) for xx in range(5) for yy in range(5) if (xx*yy+xx+yy)%3!=0]) if tool['id']=='qr-gen' else ''
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 360" role="img" aria-label="{ESC(tool['name'])} illustrated preview">
 <defs><linearGradient id="bg" x2="1" y2="1"><stop stop-color="{c}" stop-opacity=".22"/><stop offset="1" stop-color="#ffffff" stop-opacity=".05"/></linearGradient><linearGradient id="card" x2="0" y2="1"><stop stop-color="#fff"/><stop offset="1" stop-color="#f7f7ff"/></linearGradient><filter id="ds" x="-50%" y="-60%" width="220%" height="230%"><feDropShadow dx="0" dy="18" stdDeviation="17" flood-color="#3d2a77" flood-opacity=".14"/></filter></defs>
 <ellipse cx="305" cy="186" rx="265" ry="149" fill="url(#bg)"/><circle cx="95" cy="75" r="12" fill="{c}" opacity=".35"/><circle cx="490" cy="299" r="18" fill="{c}" opacity=".14"/>
 <g transform="translate(90 48) rotate(-8 95 125)" filter="url(#ds)"><rect width="196" height="255" rx="19" fill="url(#card)" stroke="#e7e7fc" stroke-width="2"/><rect x="19" y="18" width="47" height="47" rx="11" fill="{c}" opacity=".13"/><text x="42" y="47" text-anchor="middle" font-family="Arial,sans-serif" font-size="14" font-weight="900" fill="{c}">{ESC(left)}</text><rect x="20" y="91" width="156" height="9" rx="4.5" fill="#d7d9ed"/><rect x="20" y="114" width="135" height="8" rx="4" fill="#e3e5f1"/><rect x="20" y="136" width="147" height="8" rx="4" fill="#e3e5f1"/><rect x="20" y="158" width="101" height="8" rx="4" fill="#e3e5f1"/><rect x="20" y="192" width="155" height="39" rx="9" fill="{c}" opacity=".08"/></g>
 <g transform="translate(329 65) rotate(8 95 125)" filter="url(#ds)"><rect width="184" height="237" rx="18" fill="#fff" stroke="#eceafa" stroke-width="2"/><rect x="18" y="18" width="65" height="65" rx="14" fill="{c}" opacity=".94"/><text x="50" y="56" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="900" fill="#fff">{ESC(right)}</text>{dotgrid}<rect x="18" y="111" width="145" height="9" rx="4.5" fill="#d6daee"/><rect x="18" y="136" width="125" height="9" rx="4.5" fill="#e5e6f2"/><rect x="18" y="161" width="142" height="9" rx="4.5" fill="#e5e6f2"/><rect x="18" y="186" width="85" height="9" rx="4.5" fill="#e5e6f2"/></g>
 <g filter="url(#ds)"><circle cx="305" cy="171" r="36" fill="{c}"/><text x="305" y="184" text-anchor="middle" font-family="Arial,sans-serif" font-size="36" font-weight="800" fill="#fff">{ESC(arrow)}</text></g></svg>'''

HERO_SVG='''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 720 540" role="img" aria-label="Document conversion workspace illustration"><defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#d6caff"/><stop offset="1" stop-color="#f7f2ff"/></linearGradient><linearGradient id="screen" x1="0" x2="1" y1="0" y2="1"><stop stop-color="#a194fb"/><stop offset="1" stop-color="#5439dc"/></linearGradient><filter id="shadow"><feDropShadow dx="0" dy="23" stdDeviation="22" flood-color="#352088" flood-opacity=".19"/></filter></defs><ellipse cx="373" cy="262" rx="318" ry="229" fill="url(#bg)"/><circle cx="84" cy="81" r="18" fill="#a393fa" opacity=".5"/><circle cx="647" cy="414" r="13" fill="#7de7d2"/><g filter="url(#shadow)"><rect x="151" y="123" width="406" height="285" rx="23" fill="#261b67"/><rect x="164" y="137" width="381" height="252" rx="13" fill="url(#screen)"/><rect x="137" y="398" width="430" height="28" rx="10" fill="#b6b0e0"/><path d="M110 421h488l-34 22H144z" fill="#dad5fc"/></g><g filter="url(#shadow)"><rect x="286" y="62" width="205" height="271" rx="19" fill="#fff"/><rect x="309" y="87" width="65" height="52" rx="12" fill="#eeeaff"/><text x="342" y="123" font-family="Arial" font-size="29" text-anchor="middle" fill="#7757ee" font-weight="800">T</text><rect x="309" y="158" width="152" height="11" rx="5" fill="#cbd0ed"/><rect x="309" y="183" width="149" height="10" rx="5" fill="#dfe1f4"/><rect x="309" y="207" width="124" height="10" rx="5" fill="#dfe1f4"/><rect x="309" y="231" width="154" height="10" rx="5" fill="#dfe1f4"/><rect x="309" y="255" width="96" height="10" rx="5" fill="#dfe1f4"/></g><g filter="url(#shadow)"><rect x="469" y="150" width="157" height="192" rx="16" fill="#fff"/><rect x="483" y="167" width="129" height="110" rx="10" fill="#ddf0fe"/><circle cx="584" cy="194" r="14" fill="#ffc764"/><path d="M487 265l36-46 29 26 25-30 36 50z" fill="#7ebbe8"/><path d="M490 270l39-33 17 13 22-23 38 43z" fill="#39ad91"/><rect x="485" y="294" width="108" height="10" rx="5" fill="#dfe1f4"/><rect x="485" y="315" width="82" height="9" rx="5" fill="#e8e9f5"/></g><g filter="url(#shadow)"><rect x="106" y="190" width="130" height="169" rx="17" fill="#fff"/><rect x="126" y="212" width="89" height="42" rx="11" fill="#fa666f"/><text x="171" y="240" text-anchor="middle" font-family="Arial" font-size="22" font-weight="900" fill="#fff">PDF</text><rect x="126" y="272" width="87" height="10" rx="5" fill="#cbd0ed"/><rect x="126" y="296" width="76" height="10" rx="5" fill="#dee0ef"/><rect x="126" y="320" width="65" height="10" rx="5" fill="#dee0ef"/></g><circle cx="240" cy="194" r="25" fill="#fff" opacity=".87"/><text x="240" y="203" font-family="Arial" font-size="25" text-anchor="middle" fill="#7555ef">↗</text><circle cx="581" cy="106" r="26" fill="#fff"/><path d="M569 106h24m-12-12v24" stroke="#8661ed" stroke-width="5" stroke-linecap="round"/></svg>'''

# Site build helpers.
def relative(depth,path):return '../'*depth + path

def url_for(tool,depth=0):return relative(depth,'tools/'+tool['slug']+'/index.html')

def full_url(path):
    base=SITE.get('base_url','').strip().rstrip('/')
    return (base+'/'+path.lstrip('/')) if re.match(r'^https?://[^/]+',base) else ''

def ads_config():
    ads=DATA.get('ads', {})
    client=str(ads.get('client','')).strip()
    slots=ads.get('slots',{})
    active=bool(ads.get('enabled')) and bool(re.fullmatch(r'ca-pub-\d{12,}', client))
    return ads,client,slots,active

def ad_slot(key, mode='wide'):
    ads,client,slots,enabled=ads_config()
    code=str(slots.get(key,'')).strip()
    label='Advertisement'
    ad_class='ad-placement--sidebar' if mode=='sidebar' else ('ad-placement--inline' if mode=='inline' else 'ad-placement--wide')
    # AdSense client and slot IDs MUST be supplied by the site owner. No fake ads.
    if enabled and re.fullmatch(r'\d{6,}', code):
        return f'''<aside class="ad-placement {ad_class}" aria-label="{label}" data-ad-placement="{ESC(key)}"><span class="ad-label">{label}</span><ins class="adsbygoogle" style="display:block" data-ad-client="{ESC(client)}" data-ad-slot="{ESC(code)}" data-ad-format="auto" data-full-width-responsive="true"></ins><script>(window.adsbygoogle=window.adsbygoogle||[]).push({{}});</script></aside>'''
    return f'''<aside class="ad-placement {ad_class}" aria-label="Reserved advertisement space" data-ad-placement="{ESC(key)}"><span class="ad-label">{label}</span><div class="ad-reserved"><strong>Ad space reserved</strong><span>For future display advertising</span></div></aside>'''

def document_head(title, description, current_path, depth, hero=None):
    canonical=full_url(current_path)
    favicon=relative(depth,'assets/favicon.svg')
    art=full_url(hero) if hero else ''
    out=f'''<!DOCTYPE html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#f8f9fe"><title>{ESC(title)}</title><meta name="description" content="{ESC(description)}"><meta name="robots" content="index,follow,max-image-preview:large"><meta property="og:type" content="website"><meta property="og:title" content="{ESC(title)}"><meta property="og:description" content="{ESC(description)}">'''
    if canonical:out+=f'<link rel="canonical" href="{ESC(canonical)}"><meta property="og:url" content="{ESC(canonical)}">'
    if art:out+=f'<meta property="og:image" content="{ESC(art)}">'
    ads,client,slots,active=ads_config()
    if active and any(re.fullmatch(r'\d{6,}',str(v).strip()) for v in slots.values()):
        out+=f'<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={ESC(client)}" crossorigin="anonymous"></script>'

    out+=f'''<link rel="icon" href="{favicon}" type="image/svg+xml"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Manrope:wght@400;500;600;700;800&family=Noto+Naskh+Arabic:wght@400;500;600&family=Noto+Nastaliq+Urdu:wght@400;500;600&display=swap" rel="stylesheet"><link rel="stylesheet" href="{relative(depth,'assets/app.css')}">'''
    for src in ["https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js","https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js","https://unpkg.com/pdf-lib@1.17.1/dist/pdf-lib.min.js","https://unpkg.com/docx@8.5.0/build/index.umd.js","https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js","https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.js","https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"]:
        out+=f'<script defer src="{src}"></script>'
    out+=f'<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.css"></head>'
    return out

def header(depth,active='home'):
    logo=relative(depth,'index.html'); tools=relative(depth,'index.html#tools'); articles=relative(depth,'articles/index.html')
    return f'''<body><div class="app-shell"><header class="topbar"><a class="brand" id="logoHome" href="{logo}" aria-label="SnapText Studio home"><span class="brand-mark"><svg viewBox="0 0 32 32" aria-hidden="true"><path d="M8 4.75h10.5L25 11.2v15.05A2.75 2.75 0 0 1 22.25 29h-14.5A2.75 2.75 0 0 1 5 26.25V7.5a2.75 2.75 0 0 1 3-2.75Z" stroke="white" stroke-width="2" fill="none"/><path d="M18 5v6.5h6.5M10 17h12M10 21h12M10 25h7" stroke="white" stroke-width="2" fill="none"/></svg></span><span class="brand-name">snaptext<span>studio</span></span></a><nav class="nav-desktop" aria-label="Main navigation"><a href="{logo}" {'aria-current="page"' if active=='home' else ''}>Home</a><a href="{tools}" {'aria-current="page"' if active=='tools' else ''}>All tools</a><a href="{url_for(TOOLS['image-to-text'],depth)}">Image to text</a><a href="{articles}" {'aria-current="page"' if active=='articles' else ''}>Guides</a></nav><div class="topbar-right"><span class="privacy-pill"><span class="privacy-dot"></span> Browser-based</span><a class="btn nav-cta" id="navToolsBtn" href="{tools}">Explore tools ↗</a><button class="theme-toggle" id="themeToggle" type="button" aria-label="Toggle light or dark theme" title="Toggle theme"><svg id="themeIcon" viewBox="0 0 24 24"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z"/></svg></button></div></header>'''

def footer(depth):
    home=relative(depth,'index.html'); articles=relative(depth,'articles/index.html')
    return f'''<div class="footer-wrap"><footer class="footer"><a id="footerLogo" class="brand footer-brand" href="{home}"><span class="brand-mark"><svg viewBox="0 0 32 32" aria-hidden="true"><path d="M8 4.75h10.5L25 11.2v15.05A2.75 2.75 0 0 1 22.25 29h-14.5A2.75 2.75 0 0 1 5 26.25V7.5a2.75 2.75 0 0 1 3-2.75Z" stroke="white" stroke-width="2" fill="none"/><path d="M18 5v6.5h6.5M10 17h12M10 21h12M10 25h7" stroke="white" stroke-width="2" fill="none"/></svg></span><span class="brand-name">snaptext<span>studio</span></span></a><div class="footer-links"><a href="{home}">Home</a><a href="{home}#tools">All tools</a><a href="{url_for(TOOLS['image-to-text'],depth)}">OCR</a><a href="{articles}">Articles</a></div><span class="footer-right">© {date.today().year} SnapText Studio</span></footer></div></div><div class="toast" id="toast" role="status" aria-live="polite"></div>'''

def scripts(depth):
    routes={t['id']:url_for(t,depth) for t in ALL_TOOLS};routes['home']=relative(depth,'index.html')
    return f'''<script>window.SNAPTEXT_HOME={json.dumps(routes['home'])};window.SNAPTEXT_ROUTES={json.dumps(routes)};</script><script defer src="{relative(depth,'assets/app.js')}"></script></body></html>'''

def breadcrumbs(depth,tail,part='tools'):
    home=relative(depth,'index.html'); second=relative(depth,'articles/index.html') if part=='articles' else home+'#tools'
    label='Articles' if part=='articles' else 'All tools'
    return f'''<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="{home}">Home</a><span>›</span><a href="{second}">{label}</a><span>›</span><span aria-current="page">{ESC(tail)}</span></nav>'''

def tool_tile(t,depth):
    href=url_for(t,depth); image=relative(depth,'assets/illustrations/'+t['slug']+'.svg')
    return f'''<a class="tool-tile" data-group="{ESC(t['group'])}" href="{href}" style="--tile-color:{t['color']}"><div class="tile-visual"><img src="{image}" width="450" height="270" loading="lazy" alt="Illustration of {ESC(t['name'])}"></div><div class="tile-body"><span class="tile-meta">{ESC(t['label'])}</span><h3>{ESC(t['name'])}</h3><p>{ESC(t['subtitle'])}</p><div class="tile-bottom"><span>Open tool</span><span aria-hidden="true">↗</span></div></div></a>'''

def tool_directory(depth,show_title=True):
    heading='''<div class="section-heading"><div><span class="kicker">YOUR PRODUCTIVITY TOOLKIT</span><h2>Every tool, ready when you are.</h2><p>Choose what you need. Each tool has its own dedicated workspace and practical guide.</p></div><a class="section-link" href="'''+relative(depth,'articles/index.html')+'''">Explore guides ↗</a></div>''' if show_title else ''
    filters='<div class="filter-bar" role="group" aria-label="Filter tools">'+''.join(f'<button type="button" data-filter="{ESC(g)}" aria-pressed="{str(i==0).lower()}">{ESC(g)}</button>' for i,g in enumerate(['All']+GROUPS))+'</div>'
    return '<section class="tools-gallery" id="tools">'+heading+filters+'<div class="tools-cards">'+''.join(tool_tile(t,depth) for t in ALL_TOOLS)+'</div></section>'

def article_cards(depth):
    return '<div class="blog-grid">'+''.join(f'''<a class="blog-card" href="{relative(depth,'articles/'+a['slug']+'/index.html')}"><span>KNOWLEDGE BASE · GUIDE</span><h3>{ESC(a['title'])}</h3><p>{ESC(a['excerpt'])}</p></a>''' for a in DATA['articles'])+'</div>'

def original_workspace():
    node=CORE.find('section',class_='workspace')
    assert node
    text=str(node).replace('class="workspace"','class="workspace" id="ocr"',1)
    # Existing placeholder contains unescaped quotes in original, which beautifulsoup normalizes; replace with a clean concise value.
    soup=BeautifulSoup(text,'html.parser')
    ta=soup.find('textarea',id='textOutput')
    ta['placeholder']='Your extracted text will appear here. Upload an image to get started, or type here to create your own document.'
    return str(soup)

def editorial(t,depth):
    toc=['How it works']+[p['heading'] for p in t['article']]+['Frequently asked questions']
    def ident(i):return 'section-'+str(i)
    steps=''.join(f'<li>{ESC(v)}</li>' for v in t['steps'])
    article=''.join(f'<section id="{ident(i+1)}"><h2>{ESC(s["heading"])}</h2>'+''.join('<p>'+ESC(x)+'</p>' for x in s['paragraphs'])+'</section>' for i,s in enumerate(t['article']))
    faqs=''.join(f'<details><summary>{ESC(f["q"])}</summary><p>{ESC(f["a"])}</p></details>' for f in t['faqs'])
    related=[p for p in ALL_TOOLS if p['id']!=t['id'] and p['group']==t['group']][:3]
    if len(related)<3: related += [p for p in ALL_TOOLS if p['id'] not in {x['id'] for x in related} and p['id']!=t['id']][:3-len(related)]
    reading=[a for a in DATA['articles'] if a.get('related_tool')==t['id']]
    related_reading='<section class="related-reading"><h2>Helpful guides</h2>'+''.join(f'<p><a href="{relative(depth,"articles/"+a["slug"]+"/index.html")}">{ESC(a["title"])} ↗</a></p>' for a in reading)+'</section>' if reading else ''
    return f'''<div class="editorial-grid"><article class="editorial"><p class="intro-text">{ESC(t['intro'])}</p><section id="section-0"><h2>How to use {ESC(t['name'])}</h2><ol class="steps-list">{steps}</ol></section>{article}<section id="section-{len(t['article'])+1}"><h2>Frequently asked questions</h2><div class="faq-list">{faqs}</div></section>{related_reading}</article><aside class="editorial-aside"><div class="article-toc"><h3>On this page</h3>{''.join(f'<a href="#{ident(i)}">{ESC(title)}</a>' for i,title in enumerate(toc))}</div>{ad_slot('tool_sidebar','sidebar')}</aside></div><section class="related-tools"><div class="section-heading"><div><span class="kicker">KEEP WORKING</span><h2>Related tools</h2></div></div><div class="related-grid">{''.join(f'<a href="{url_for(p,depth)}">{ESC(p["name"])} ↗</a>' for p in related)}</div></section>'''

def tool_page(t):
    depth=2; img=relative(depth,'assets/illustrations/'+t['slug']+'.svg'); path='tools/'+t['slug']+'/'
    main=f'''<main class="tool-page page-body" id="tool-{ESC(t['id'])}" data-tool="{ESC(t['id'])}">{breadcrumbs(depth,t['name'])}<div class="tool-hero"><div><span class="kicker">{ESC(t['label'])}</span><h1>{ESC(t['name'])}</h1><p>{ESC(t['subtitle'])}</p><div class="tagline-row"><span class="small-tag"><b>✓</b> No sign-up</span><span class="small-tag">Browser-based processing</span><span class="small-tag">Free to use</span></div></div><img src="{img}" width="450" height="270" alt="{ESC(t['name'])} conversion illustration"></div>'''
    if t['id']=='image-to-text':
        main+='<div class="home-workspace" style="padding:0 0 45px">'+original_workspace()+'</div>'
    else:
        node=CORE.find('main',id='tool-'+t['id'])
        assert node
        form=BeautifulSoup(str(node.find('div',class_='tool-page-card')),'html.parser')
        for label in form.select('label.file-trigger'):
            target=label.get('for')
            zone=form.new_tag('div',attrs={'class':'enhanced-drop','data-drop-input':target})
            label.wrap(zone)
            help_text=form.new_tag('small');help_text.string='Drop your file here, or select from your device'
            zone.append(help_text)
            inp=form.find('input',id=target)
            if inp:
                lst=form.new_tag('ol',attrs={'class':'file-list','data-file-list':target,'aria-live':'polite'})
                inp.insert_after(lst)
        form_html=str(form)
        main+=f'''<div class="tool-workbench"><section aria-label="{ESC(t['name'])} tool">{form_html}</section><aside class="workbench-side"><img src="{img}" alt="" loading="lazy" width="450" height="270"><h3>Before you begin</h3><p>Follow these quick steps to get the best result.</p><ul>{''.join('<li>'+ESC(x)+'</li>' for x in t['steps'][:3])}</ul></aside></div>'''
    main+=ad_slot('tool_inline','inline')+editorial(t,depth)+'</main>'
    head=document_head(t['seo_title'],t['meta_description'],path,depth,'assets/illustrations/'+t['slug']+'.svg')
    schema={'@context':'https://schema.org','@type':'WebApplication','name':t['name'],'description':t['subtitle'],'applicationCategory':'UtilitiesApplication','operatingSystem':'Any','isAccessibleForFree':True}
    if full_url(path):schema['url']=full_url(path)
    head=head.replace('</head>','<script type="application/ld+json">'+json.dumps(schema,ensure_ascii=False).replace('</','<\\/')+'</script></head>')
    return head+header(depth,'tools')+main+footer(depth)+scripts(depth)

def home_page():
    t=TOOLS['image-to-text']; depth=0
    hero='''<section class="hero-new"><div><span class="eyebrow-new">Your all-in-one document workspace</span><h1>Every document task. <em>Beautifully simple.</em></h1><p>Convert PDFs, extract text, edit images and organize files in one thoughtfully designed toolkit. No complicated setup — just choose a tool and get things done.</p><div class="hero-actions"><a class="btn btn-main" href="#tools">Explore 12 tools <span aria-hidden="true">↗</span></a><a class="btn btn-outline" href="#ocr">Start with OCR</a></div><div class="trust-row"><span><i>✦</i> Made for everyday work</span><span><i>✓</i> No account required</span><span><i>▣</i> Browser-based tools</span></div></div><img class="hero-art" src="assets/hero-studio.svg" alt="Illustration of PDF, images and text documents in a workspace" width="720" height="540"></section>'''
    tools=tool_directory(0)
    section='''<section class="home-workspace"><div class="section-heading"><div><span class="kicker">SIGNATURE WORKSPACE</span><h2>From image to editable text.</h2><p>Drop in a screenshot, photo or scan. Extract the words, make them yours, and export.</p></div><a class="section-link" href="tools/image-to-text/index.html">Full OCR guide ↗</a></div>'''+original_workspace()+'''</section>'''
    benefits='''<section class="benefits" aria-label="Benefits"><div class="benefit"><span class="emoji">🔐</span><h3>Built for local workflows</h3><p>File processing runs in the browser. Some engines load code and language resources from CDNs.</p></div><div class="benefit"><span class="emoji">✨</span><h3>Simple by design</h3><p>Focused, accessible workspaces with clear steps and feedback.</p></div><div class="benefit"><span class="emoji">🗂️</span><h3>All your essentials</h3><p>OCR, PDF conversion, image tools, cropping and QR codes in one place.</p></div><div class="benefit"><span class="emoji">📱</span><h3>Works across devices</h3><p>Responsive layouts for a laptop, tablet or mobile browser.</p></div></section>'''
    blogs='''<section class="article-preview"><div class="section-heading"><div><span class="kicker">LEARN & EXPLORE</span><h2>Practical guides.</h2><p>Helpful explanations so you can choose the right tool and get better results.</p></div><a class="section-link" href="articles/index.html">All articles ↗</a></div>'''+article_cards(0)+'</section>'
    return document_head(SITE['home_title'],SITE['home_description'],'',0,'assets/hero-studio.svg')+header(0,'home')+'<main class="page-body">'+hero+ad_slot('home_leaderboard')+section+ad_slot('home_middle')+tools+benefits+blogs+'</main>'+footer(0)+scripts(0)

def blog_index():
    depth=1
    page='''<main class="blog-index page-body"><span class="kicker">DOCUMENT KNOW-HOW</span><h1>Tips, guides & articles.</h1><p class="page-lead">Clear, practical explanations for everyday PDF, image and text workflows.</p>'''+ad_slot('article_index')+article_cards(depth)+'</main>'
    return document_head('PDF, OCR & Image Guides | SnapText Studio','Browse step-by-step tutorials for OCR, PDF conversion, image formats and document organization.','articles/',depth)+header(depth,'articles')+page+footer(depth)+scripts(depth)

def blog_page(a):
    depth=2;tool=TOOLS.get(a['related_tool']); link=url_for(tool,depth) if tool else relative(depth,'index.html')
    sections=''.join(f'<section id="post-{i}"><h2>{ESC(s["heading"])}</h2>'+''.join(f'<p>{ESC(v)}</p>' for v in s['paragraphs'])+'</section>' for i,s in enumerate(a['sections']))
    toc=''.join(f'<a href="#post-{i}">{ESC(s["heading"])}</a>' for i,s in enumerate(a['sections']))
    other=[other for other in DATA['articles'] if other['slug']!=a['slug']][:3]
    more=''.join(f'<p><a href="{relative(depth,"articles/"+b["slug"]+"/index.html")}">{ESC(b["title"])} ↗</a></p>' for b in other)
    body=f'''<main class="article-page page-body">{breadcrumbs(depth,a['title'],'articles')}<div class="blog-hero"><span class="kicker">SNAPTEXT KNOWLEDGE BASE</span><h1>{ESC(a['title'])}</h1><p>{ESC(a['excerpt'])}</p><a href="{link}" class="btn btn-main">Try {ESC(tool['name'] if tool else 'the tool')} ↗</a></div>{ad_slot('article_inline','inline')}<div class="editorial-grid"><article class="editorial">{sections}<div class="related-reading"><h2>More practical guides</h2>{more}</div><div class="related-tools"><h2>Ready to try it?</h2><p>Open the matching tool and follow the steps in your browser.</p><a href="{link}" class="btn btn-main">Open {ESC(tool['name'] if tool else 'tools')} ↗</a></div></article><aside class="editorial-aside"><div class="article-toc"><h3>In this guide</h3>{toc}</div>{ad_slot('article_sidebar','sidebar')}</aside></div></main>'''
    return document_head(a['title']+' | SnapText Studio',a['excerpt'],'articles/'+a['slug']+'/',depth)+header(depth,'articles')+body+footer(depth)+scripts(depth)

def build(destination):
    destination.mkdir(parents=True,exist_ok=True)
    assets=destination/'assets';illustrations=assets/'illustrations'; illustrations.mkdir(parents=True,exist_ok=True)
    (assets/'app.css').write_text(LEGACY_CSS+'\n'+THEME,encoding='utf-8')
    (assets/'app.js').write_text(TRANSFER+'\n'+SCRIPT+'\n'+ENHANCEMENTS,encoding='utf-8')
    (assets/'hero-studio.svg').write_text(HERO_SVG,encoding='utf-8')
    (assets/'favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="17" fill="#7653f0"/><path d="M19 11h20l9 9v33H19z" fill="none" stroke="white" stroke-width="4" stroke-linejoin="round"/><path d="M39 11v12h9M25 31h16M25 39h16M25 47h11" fill="none" stroke="white" stroke-width="4" stroke-linecap="round"/></svg>',encoding='utf-8')
    for t in ALL_TOOLS:
        (illustrations/(t['slug']+'.svg')).write_text(create_illustration(t),encoding='utf-8')
        folder=destination/'tools'/t['slug'];folder.mkdir(parents=True,exist_ok=True)
        (folder/'index.html').write_text(tool_page(t),encoding='utf-8')
    (destination/'index.html').write_text(home_page(),encoding='utf-8')
    folder=destination/'articles';folder.mkdir(exist_ok=True)
    (folder/'index.html').write_text(blog_index(),encoding='utf-8')
    for a in DATA['articles']:
        sub=folder/a['slug'];sub.mkdir(exist_ok=True)
        (sub/'index.html').write_text(blog_page(a),encoding='utf-8')
    (destination/'.nojekyll').write_text('',encoding='utf-8')
    (destination/'robots.txt').write_text('User-agent: *\nAllow: /\n'+('Sitemap: '+full_url('sitemap.xml')+'\n' if full_url('sitemap.xml') else ''),encoding='utf-8')
    urls=['']+['tools/'+t['slug']+'/' for t in ALL_TOOLS]+['articles/']+['articles/'+a['slug']+'/' for a in DATA['articles']]
    if full_url(''):
        xml='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join('<url><loc>'+ESC(full_url(x))+'</loc></url>' for x in urls)+'</urlset>'
        (destination/'sitemap.xml').write_text(xml,encoding='utf-8')
    elif (destination/'sitemap.xml').exists(): (destination/'sitemap.xml').unlink()
    print(f'Generated {len(urls)} indexable HTML URLs ({len(ALL_TOOLS)} dedicated tools and {len(DATA["articles"])} guides) in {destination}')
    if not full_url(''):print('IMPORTANT: Set site.base_url to your public HTTPS domain, then rebuild to generate canonical URLs and sitemap.xml.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',default='dist');args=p.parse_args()
    destination=Path(args.output);destination=destination if destination.is_absolute() else ROOT/destination
    build(destination)
