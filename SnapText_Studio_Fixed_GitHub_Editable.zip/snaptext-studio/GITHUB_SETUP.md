# Publish SnapText Studio on GitHub Pages

## Publish the website to GitHub Pages — straightforward route

1. Download the **Ready-to-Upload** ZIP and extract it. (If using the complete editable source, the already-built `docs/` folder contains the same website files.)
2. Sign in to [GitHub](https://github.com), create a repository such as `snaptext-studio` and choose **Public** if using free GitHub Pages.
3. In the repository, click **Add file → Upload files** and upload **the contents of the extracted ZIP**, so `index.html`, `articles/`, `tools/`, `assets/`, `.nojekyll` and `robots.txt` are at the repository root. For many folders, use GitHub Desktop or Git on your machine rather than the web file upload interface.
4. Commit changes, then go to **Settings → Pages → Build and deployment → Deploy from a branch → main → /(root) → Save**.
5. Your default project-site URL should be `https://YOUR_GITHUB_USERNAME.github.io/snaptext-studio/` (if you used that repository name). This is not automatically a custom domain.
6. In the **editable project**, enter this exact published HTTPS URL into **Content Studio → Site & SEO settings → Live HTTPS domain**. Export `site-content.json`, replace the project copy, run `python build.py`, and re-upload refreshed website files. That generates the correct sitemap and canonical tags, including the repository path.
7. In **Google Search Console**, verify your site and submit `sitemap.xml` only after it exists on the published URL.

### Alternative for the complete source code repository

The complete editable ZIP includes `build.py`, `site-content.json`, `content-editor.html`, and a fully generated `docs/` folder. Upload the source files to GitHub and use **Settings → Pages → Deploy from a branch → main → /docs**. When you rebuild locally, also run `python build.py --output docs` and push the updated `docs/` files, because GitHub Pages will serve the `docs/` files, not the `dist/` files. Do not include your personal accounts, API keys or unapproved advertisement IDs in a public repository.

### Quick terminal commands (optional)

After extracting the **complete editable project**, inside the folder:

```bash
git init
git add .
git commit -m "Fix routes, internal links and add ad placements"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/snaptext-studio.git
git push -u origin main
```

Create the empty repository on GitHub first. Follow the branch and `/docs` setup above. Replace the placeholder username with your actual account; don't use that example as a real destination.


